# Nano Addon 0.3.0 — Water-oriented structure

Target:
- Minecraft 1.21.11
- Yarn 1.21.11+build.6
- Fabric Loader 0.19.5
- Fabric API 0.141.6+1.21.11
- Loom 1.18-SNAPSHOT
- Meteor 1.21.11-SNAPSHOT
- Java 21

Modules:
- Sus Chunk
- Chunk Finder
- Amethyst Finder (> 12 clusters => 13+)
- Storage ESP
- Player ESP
- Freecam
- Freelook
- Camera Tweaks

The implementation is an independent Nano implementation. Water Client is used only as a behavioral/settings reference.

Performance:
- scanning is separated from rendering
- loaded chunks only
- bounded chunks-per-tick
- shared queue/cache
- flat 16x16 chunk markers
