package com.nano.addon.render;

import com.nano.addon.util.ChunkMark;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;

/**
 * Central place for Nano's flat chunk markers.
 * Rendering is intentionally kept separate from scanning.
 */
public final class ChunkRenderer {
    private ChunkRenderer() {}

    public static void flatTop(Render3DEvent event, ChunkMark mark, int y, double height) {
        ChunkPos p = mark.pos();
        double x1 = p.getStartX();
        double z1 = p.getStartZ();
        double x2 = p.getEndX() + 1.0;
        double z2 = p.getEndZ() + 1.0;

        // A thin box with negligible height gives the requested flat 16x16 surface.
        event.renderer.box(
            new Box(x1, y, z1, x2, y + height, z2),
            mark.argb(),
            false
        );
    }
}
