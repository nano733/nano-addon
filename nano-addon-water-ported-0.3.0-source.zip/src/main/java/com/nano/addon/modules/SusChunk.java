package com.nano.addon.modules;

import com.nano.addon.render.ChunkRenderer;
import com.nano.addon.util.ChunkMark;
import com.nano.addon.util.ChunkScanService;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SusChunk extends BaseNanoModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder().name("scan-radius").defaultValue(4).min(1).sliderMax(16).build());
    private final Setting<Integer> budget = sgGeneral.add(new IntSetting.Builder().name("chunks-per-tick").defaultValue(1).min(1).sliderMax(8).build());
    private final Setting<Integer> minScore = sgGeneral.add(new IntSetting.Builder().name("min-score").defaultValue(30).min(1).sliderMax(100).build());
    private final Setting<Integer> minY = sgGeneral.add(new IntSetting.Builder().name("min-y").defaultValue(-64).build());
    private final Setting<Integer> maxY = sgGeneral.add(new IntSetting.Builder().name("max-y").defaultValue(96).build());
    private final Setting<Integer> surfaceY = sgRender.add(new IntSetting.Builder().name("surface-y").defaultValue(65).build());
    private final Setting<Color> fillColor = sgRender.add(new ColorSetting.Builder().name("fill-color").defaultValue(new Color(255, 35, 35, 95)).build());

    private final Map<Long, ChunkMark> marks = new ConcurrentHashMap<>();
    private int ticks;

    public SusChunk() {
        super("sus-chunk", "Performance-oriented suspicious chunk finder.");
    }

    @Override
    public void onActivate() {
        marks.clear();
        ticks = 0;
        ChunkScanService.get().clear();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (MinecraftClient.getInstance().player == null) return;
        if ((ticks++ % 20) == 0) {
            ChunkScanService.get().enqueueAround(MinecraftClient.getInstance().player.getChunkPos(), radius.get());
        }
        ChunkScanService.get().drain(budget.get(), chunk -> {
            int score = score(chunk);
            if (score >= minScore.get()) {
                marks.put(chunk.getPos().toLong(), new ChunkMark(chunk.getPos(), fillColor.get().getPacked()));
            } else {
                marks.remove(chunk.getPos().toLong());
            }
        });
        for (ChunkMark mark : marks.values()) {
            ChunkRenderer.flatTop(event, mark, surfaceY.get(), 0.02);
        }
    }

    private int score(WorldChunk chunk) {
        // Safe baseline heuristic. Add further Water-observed signals here without
        // turning the render loop into a full world scan.
        int score = 0;
        if (!chunk.getBlockEntities().isEmpty()) score += 15;
        return score;
    }
}
