package com.nano.addon.modules;

import meteordevelopment.meteorclient.settings.*;

public final class CameraTweaks extends BaseNanoModule {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> distance = sg.add(new DoubleSetting.Builder().name("camera-distance").defaultValue(4.0).min(0.1).sliderMax(12).build());
    private final Setting<Double> fovScale = sg.add(new DoubleSetting.Builder().name("fov-scale").defaultValue(1.0).min(0.1).sliderMax(3).build());
    private final Setting<Boolean> smooth = sg.add(new BoolSetting.Builder().name("smooth").defaultValue(true).build());

    public CameraTweaks() {
        super("camera-tweaks", "Camera controls kept independent from ESP and chunk scanning.");
    }
}
