package com.nano.addon.modules;

import meteordevelopment.meteorclient.settings.*;

public final class Freelook extends BaseNanoModule {
    public enum Activation { Hold, Toggle }

    private final SettingGroup sg = settings.getDefaultGroup();
    public final Setting<Activation> activation = sg.add(new EnumSetting.Builder<Activation>().name("activation").defaultValue(Activation.Hold).build());
    public final Setting<Double> sensitivity = sg.add(new DoubleSetting.Builder().name("sensitivity").defaultValue(1.0).min(0.05).sliderMax(4).build());
    public final Setting<Boolean> invertY = sg.add(new BoolSetting.Builder().name("invert-y").defaultValue(false).build());
    public final Setting<Boolean> wallClip = sg.add(new BoolSetting.Builder().name("wall-clip").defaultValue(false).build());

    public Freelook() {
        super("freelook", "Water-style freelook controls.");
    }
}
