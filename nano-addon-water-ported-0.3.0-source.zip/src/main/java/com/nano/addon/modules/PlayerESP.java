package com.nano.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;

public final class PlayerESP extends BaseNanoModule {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> range = sg.add(new IntSetting.Builder().name("range").defaultValue(128).min(1).sliderMax(256).build());
    private final Setting<Boolean> tracers = sg.add(new BoolSetting.Builder().name("tracers").defaultValue(false).build());
    private final Setting<Integer> fillAlpha = sg.add(new IntSetting.Builder().name("fill-alpha").defaultValue(70).min(0).max(255).sliderMax(255).build());
    private final Setting<Color> fillColor = sg.add(new ColorSetting.Builder().name("fill-color").defaultValue(new Color(255, 255, 255, 100)).build());
    private final Setting<Color> tracerColor = sg.add(new ColorSetting.Builder().name("tracer-color").defaultValue(new Color(255, 255, 255, 200)).build());

    public PlayerESP() {
        super("player-esp", "Player ESP with Water-style range, fill and tracer settings.");
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        // Final entity rendering hook kept separate from scanner code.
    }
}
