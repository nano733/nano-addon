package com.nano.addon.modules;

import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Categories;

public abstract class BaseNanoModule extends Module {
    protected BaseNanoModule(String name, String description) {
        super(Categories.Render, name, description);
    }
}
