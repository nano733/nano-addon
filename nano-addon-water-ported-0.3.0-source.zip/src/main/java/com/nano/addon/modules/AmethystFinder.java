package com.nano.addon.modules;

import com.nano.addon.render.ChunkRenderer;
import com.nano.addon.util.ChunkMark;
import com.nano.addon.util.ChunkScanService;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class AmethystFinder extends BaseNanoModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder().name("sim-distance").defaultValue(6).min(1).sliderMax(16).build());
    private final Setting<Integer> budget = sgGeneral.add(new IntSetting.Builder().name("chunks-per-tick").defaultValue(1).min(1).sliderMax(8).build());
    private final Setting<Integer> minClusters = sgGeneral.add(new IntSetting.Builder().name("min-cluster-size").description("Chunks are marked when they contain more than this many clusters.").defaultValue(12).min(0).sliderMax(64).build());
    private final Setting<Integer> surfaceY = sgRender.add(new IntSetting.Builder().name("chunk-y").defaultValue(65).build());
    private final Setting<Color> color = sgRender.add(new ColorSetting.Builder().name("chunk-color").defaultValue(new Color(180, 80, 255, 90)).build());

    private final Map<Long, ChunkMark> marks = new ConcurrentHashMap<>();
    private final Map<Long, Integer> counts = new ConcurrentHashMap<>();
    private int ticks;

    public AmethystFinder() {
        super("amethyst-finder", "Marks loaded chunks containing more than the configured number of amethyst clusters.");
    }

    @Override
    public void onActivate() {
        marks.clear();
        counts.clear();
        ticks = 0;
        ChunkScanService.get().clear();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (MinecraftClient.getInstance().player == null) return;
        if ((ticks++ % 20) == 0) {
            ChunkScanService.get().enqueueAround(MinecraftClient.getInstance().player.getChunkPos(), radius.get());
        }

        ChunkScanService.get().drain(budget.get(), this::scan);
        for (ChunkMark mark : marks.values()) {
            ChunkRenderer.flatTop(event, mark, surfaceY.get(), 0.025);
        }
    }

    private void scan(WorldChunk chunk) {
        int count = 0;
        // Amethyst clusters are block states, not block entities. Count them directly.
        var world = MinecraftClient.getInstance().world;
        if (world == null) return;
        int minY = world.getBottomY();
        int maxY = world.getTopYInclusive();

        for (int y = minY; y <= maxY; y++) {
            for (int x = chunk.getPos().getStartX(); x < chunk.getPos().getStartX() + 16; x++) {
                for (int z = chunk.getPos().getStartZ(); z < chunk.getPos().getStartZ() + 16; z++) {
                    if (world.getBlockState(new net.minecraft.util.math.BlockPos(x, y, z)).isOf(Blocks.AMETHYST_CLUSTER)) count++;
                    if (count > minClusters.get()) break;
                }
                if (count > minClusters.get()) break;
            }
            if (count > minClusters.get()) break;
        }

        long key = chunk.getPos().toLong();
        counts.put(key, count);
        if (count > minClusters.get()) {
            marks.put(key, new ChunkMark(chunk.getPos(), color.get().getPacked()));
        } else {
            marks.remove(key);
        }
    }
}
