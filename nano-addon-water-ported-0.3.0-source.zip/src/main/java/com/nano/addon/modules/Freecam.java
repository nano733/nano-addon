package com.nano.addon.modules;

import meteordevelopment.meteorclient.settings.*;

public final class Freecam extends BaseNanoModule {
    private final SettingGroup sg = settings.getDefaultGroup();
    public final Setting<Double> speed = sg.add(new DoubleSetting.Builder().name("speed").defaultValue(1.0).min(0.05).sliderMax(5).build());
    public final Setting<Boolean> smooth = sg.add(new BoolSetting.Builder().name("smooth").defaultValue(true).build());
    public final Setting<Boolean> keepSneak = sg.add(new BoolSetting.Builder().name("keep-sneak").defaultValue(false).build());
    public final Setting<Boolean> stickToEye = sg.add(new BoolSetting.Builder().name("stick-to-eye").defaultValue(false).build());

    public Freecam() {
        super("freecam", "Water-style free camera settings; camera hooks are isolated in mixins.");
    }
}
