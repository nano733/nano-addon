package com.nano.addon.modules;

import com.nano.addon.render.ChunkRenderer;
import com.nano.addon.util.ChunkMark;
import com.nano.addon.util.ChunkScanService;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ChunkFinder extends BaseNanoModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder().name("scan-radius").defaultValue(4).min(1).sliderMax(16).build());
    private final Setting<Integer> budget = sgGeneral.add(new IntSetting.Builder().name("chunks-per-tick").defaultValue(2).min(1).sliderMax(16).build());
    private final Setting<Integer> refresh = sgGeneral.add(new IntSetting.Builder().name("refresh-ticks").defaultValue(20).min(1).sliderMax(200).build());
    private final Setting<Integer> y = sgRender.add(new IntSetting.Builder().name("surface-y").defaultValue(65).build());
    private final Setting<Color> color = sgRender.add(new ColorSetting.Builder().name("color").defaultValue(new Color(255, 220, 0, 80)).build());

    private final Map<Long, ChunkMark> marks = new ConcurrentHashMap<>();
    private int ticks;

    public ChunkFinder() {
        super("chunk-finder", "Water-style loaded chunk finder with bounded incremental work.");
    }

    @Override
    public void onActivate() {
        marks.clear();
        ticks = 0;
        ChunkScanService.get().clear();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (MinecraftClient.getInstance().player == null) return;
        if ((ticks++ % refresh.get()) == 0) {
            ChunkScanService.get().enqueueAround(MinecraftClient.getInstance().player.getChunkPos(), radius.get());
        }
        ChunkScanService.get().drain(budget.get(), chunk -> {
            ChunkPos pos = chunk.getPos();
            marks.put(pos.toLong(), new ChunkMark(pos, color.get().getPacked()));
        });
        for (ChunkMark mark : marks.values()) {
            ChunkRenderer.flatTop(event, mark, y.get(), 0.02);
        }
    }
}
