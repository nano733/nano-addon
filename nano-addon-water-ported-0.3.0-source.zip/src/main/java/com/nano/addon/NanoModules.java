package com.nano.addon;

import com.nano.addon.modules.*;
import meteordevelopment.meteorclient.systems.modules.Modules;

public final class NanoModules {
    public void register() {
        Modules modules = Modules.get();
        modules.add(new SusChunk());
        modules.add(new ChunkFinder());
        modules.add(new AmethystFinder());
        modules.add(new StorageESP());
        modules.add(new PlayerESP());
        modules.add(new Freecam());
        modules.add(new Freelook());
        modules.add(new CameraTweaks());
    }
}
