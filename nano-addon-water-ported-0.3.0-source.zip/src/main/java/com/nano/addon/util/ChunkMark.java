package com.nano.addon.util;

import net.minecraft.util.math.ChunkPos;

public record ChunkMark(ChunkPos pos, int argb) {}
