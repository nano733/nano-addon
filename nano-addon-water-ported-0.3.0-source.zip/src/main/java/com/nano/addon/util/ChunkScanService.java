package com.nano.addon.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Shared incremental scanner. It never performs a large synchronous world scan.
 * Modules enqueue chunk positions and consume a bounded amount of work per tick.
 */
public final class ChunkScanService {
    private static final ChunkScanService INSTANCE = new ChunkScanService();
    public static ChunkScanService get() { return INSTANCE; }

    private final ArrayDeque<ChunkPos> queue = new ArrayDeque<>();
    private final Set<Long> queued = new HashSet<>();

    public void enqueueAround(ChunkPos center, int radius) {
        for (int dz = -radius; dz <= radius; dz++) {
            for (int dx = -radius; dx <= radius; dx++) {
                ChunkPos pos = new ChunkPos(center.x + dx, center.z + dz);
                if (queued.add(pos.toLong())) queue.addLast(pos);
            }
        }
    }

    public int drain(int budget, Consumer<WorldChunk> consumer) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        if (world == null) {
            queue.clear();
            queued.clear();
            return 0;
        }

        int done = 0;
        while (done < budget && !queue.isEmpty()) {
            ChunkPos pos = queue.removeFirst();
            queued.remove(pos.toLong());
            WorldChunk chunk = world.getChunkManager().getWorldChunk(pos.x, pos.z);
            if (chunk != null) {
                consumer.accept(chunk);
                done++;
            }
        }
        return done;
    }

    public void clear() {
        queue.clear();
        queued.clear();
    }
}
