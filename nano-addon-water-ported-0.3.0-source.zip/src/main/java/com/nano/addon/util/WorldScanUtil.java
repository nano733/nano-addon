package com.nano.addon.util;

import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.Map;
import java.util.function.Predicate;

public final class WorldScanUtil {
    private WorldScanUtil() {}

    public static int countBlockEntities(WorldChunk chunk, Predicate<BlockEntity> predicate) {
        int count = 0;
        for (BlockEntity be : chunk.getBlockEntities().values()) {
            if (predicate.test(be)) count++;
        }
        return count;
    }

    public static int countBlocks(ClientWorld world, WorldChunk chunk, Predicate<Block> predicate, int minY, int maxY) {
        int count = 0;
        int minX = chunk.getPos().getStartX();
        int minZ = chunk.getPos().getStartZ();
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x < minX + 16; x++) {
                for (int z = minZ; z < minZ + 16; z++) {
                    if (predicate.test(world.getBlockState(new BlockPos(x, y, z)).getBlock())) count++;
                }
            }
        }
        return count;
    }
}
