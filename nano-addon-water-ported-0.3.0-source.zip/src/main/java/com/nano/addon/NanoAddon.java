package com.nano.addon;

import com.nano.addon.modules.*;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;

public final class NanoAddon extends MeteorAddon {
    public static final NanoModules MODULES = new NanoModules();

    @Override
    public void onInitialize() {
        MODULES.register();
    }

    @Override
    public void onRegisterCategories() {
        // Meteor discovers the modules through the standard Modules registry.
    }
}
