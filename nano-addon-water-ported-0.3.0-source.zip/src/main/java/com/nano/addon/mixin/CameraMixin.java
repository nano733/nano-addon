package com.nano.addon.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.render.Camera;

@Mixin(Camera.class)
public abstract class CameraMixin {
    // Reserved for the final Water-compatible freelook/freecam camera hooks.
}
